Hi there! This folder contains all branding assets for Nightlight (nightlightapp.net) that are meant to represent the brand.
A quick rundown of the terms of use:
    - Do not modify the presented assets beyond color alternation. Changing the color on the monochrome icons is fine.
    - Do not distribute these assets without permission.

These assets are a property of Nightlight located at nightlightapp.net by iTenerai
Copyright Nightlight